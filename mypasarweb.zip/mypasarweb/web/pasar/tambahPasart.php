<?php

	if($_SERVER['REQUEST_METHOD']=='POST'){

		//Mendapatkan Nilai Variable
		$name = $_POST['kode'];
		$desg = $_POST['nama'];
		$salt = $_POST['alamat'];
		$sal = $_POST['kelurahan'];

		//Pembuatan Syntax SQL
		$sql = "INSERT INTO tb_minimarket (code,adress,user) VALUES ('$kode','$nama','$alamat','$kelurahan')";

		//Import File Koneksi database
		require_once('koneksi.php');

		//Eksekusi Query database
		if(mysqli_query($con,$sql)){
			echo 'Successfully';
		}else{
			echo 'Failed';
		}

		mysqli_close($con);
	}
?>
