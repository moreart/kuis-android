package id.mypasarv2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import java.util.ArrayList;
import java.util.List;

import id.mypasarv2.Adapter.RecycleAdapter;
import id.mypasarv2.Api.ApiRest;
import id.mypasarv2.Api.RetroServer;
import id.mypasarv2.model.DataModel;
import id.mypasarv2.model.ResponseModel;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class tampilpasar extends AppCompatActivity {
    private RecyclerView mRecycler;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mManager;
    private List<DataModel> mItems = new ArrayList<>();
    ProgressBar pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tampilmarket);

        pd = (ProgressBar) findViewById(R.id.pd);
        pd.setIndeterminate(true);
        pd.setVisibility(View.VISIBLE);


        mRecycler = (RecyclerView) findViewById(R.id.recyclerTemp);
        mManager = new LinearLayoutManager(this);
        mRecycler.setLayoutManager(mManager);

        ApiRest api = RetroServer.getClient().create(ApiRest.class);
        Call<ResponseModel> getdata = api.getPasar();
        getdata.enqueue(new Callback<ResponseModel>() {
            @Override
            public void onResponse(Call<ResponseModel> call, Response<ResponseModel> response) {
                pd.setVisibility(View.GONE);
                Log.d("RETRO", "RESPONSE : " +
                        response.body().getmKodepasar());

                mItems = response.body().getResult();

                mAdapter = new RecycleAdapter(tampilpasar.this,mItems);
                mRecycler.setAdapter(mAdapter);
            }

            @Override
            public void onFailure(Call<ResponseModel> call, Throwable t) {

                pd.setVisibility(View.GONE);
//pd.setVisibility(View.GONE);

                Log.d("RETRO", "FAILED : respon gagal");

            }
        });
    }
}
