package id.mypasarv2;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import id.mypasarv2.Api.ApiRest;
import id.mypasarv2.Api.RetroServer;
import id.mypasarv2.model.ResponseModel;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    EditText kode, nama, alamat, kelurahan;
    Button btnsimpan, btntampil;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        kode = (EditText)findViewById(R.id.editkode);
        nama = (EditText) findViewById(R.id.editnama);
        alamat = (EditText) findViewById(R.id.editalamat);
        kelurahan = (EditText) findViewById(R.id.editkelurahan);
        btnsimpan = (Button)findViewById(R.id.btnsimpan);
        btntampil = (Button) findViewById(R.id.btntampil);

        Intent data = getIntent();
        final String iddata = data.getStringExtra("id");
        if(iddata != null){
            btnsimpan.setVisibility(View.GONE);
            btntampil.setVisibility(View.GONE);
            kode.setText(data.getStringExtra("kode"));
            nama.setText(data.getStringExtra("nama"));
            alamat.setText(data.getStringExtra("alamat"));
        }

        //tampil
        btntampil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,tampilpasar.class));
            }
        });

        //insert
        btnsimpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String skode = kode.getText().toString();
                String snama = nama.getText().toString();
                String salamat = alamat.getText().toString();
                String skelurahan = kelurahan.getText().toString();

                if (skode.isEmpty()){
                    kode.setError("isi kode");
                }else if(snama.isEmpty()) {
                    nama.setError("isi nama");
                } else if (salamat.isEmpty()) {
                    alamat.setError("isi alamat");
                }else if (skelurahan.isEmpty()){
                        kelurahan.setError("Isi Kelurahan");
                    }
                {
                    ApiRest api = RetroServer.getClient().create(ApiRest.class);
                    Call<ResponseModel> sendmini = api.sendPasar(skode, snama,salamat);

                    sendmini.enqueue(new Callback<ResponseModel>() {
                        @Override
                        public void onResponse(Call<ResponseModel> call, Response<ResponseModel> response) {
                            Log.d("RETRO", "response : " + response.body().toString());
                            String kodemini = response.body().getmKodepasar();

                            if (kodemini.equals("1")){
                                Toast.makeText(MainActivity.this, "data berhasil disimpan",
                                        Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(MainActivity.this, tampilpasar.class));
                                kode.getText().clear();
                                nama.getText().clear();
                                alamat.getText().clear();
                            }else {
                                Toast.makeText(MainActivity.this, "data eror",Toast.LENGTH_SHORT).show();
                            }
                        }


                        @Override
                        public void onFailure(Call<ResponseModel> call, Throwable t) {
                            Log.d("RETRO", "Falure : " + "Gagal Mengirim Request");

                        }
                    });
                }
            }
        });
    }
    @Override
    public void onBackPressed(){
        AlertDialog.Builder alert = new AlertDialog.Builder(this);
        alert.setTitle("warnig");
        alert.setMessage("do you wan to exit");

        alert.setPositiveButton("yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                MainActivity.this.finish();
            }
        });
        alert.setNegativeButton("no", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });

        AlertDialog alertDialog = alert.create(); alertDialog.show();
    }

}