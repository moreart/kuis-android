package id.mypasarv2.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

@SuppressWarnings("unused")
public class ResponseModel {
    List<DataModel> result;
    @SerializedName("kodemini")
    private String mKodepasar;
    @SerializedName("pesan")
    private String pesan;

    public List<DataModel>getResult(){
        return result;
    }

    public void setResult(List<DataModel> result) {
        this.result = result;
    }

    public String getmKodepasar() {
        return mKodepasar;
    }

    public void setmKodepasar(String mKodepasar) {
        mKodepasar = mKodepasar;
    }

    public String getPesan() {
        return pesan;
    }

    public void setPesan(String pesan) {
        pesan = pesan;
    }
}